import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.*;
/**
 * Write a description of class PokePlayer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PokePlayer extends Actor
{
    /**
     * Act - do whatever the PokePlayer wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkKeys();
        animation();
        Greenfoot.delay(10);
    }   
    private void checkKeys(){
        if(Greenfoot.isKeyDown("left")){
            setLocation(getX()-1,getY());
        } if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+1,getY());
        } if(Greenfoot.isKeyDown("up")){
            setLocation(getX(),getY()-1);
        } if(Greenfoot.isKeyDown("down")){
            setLocation(getX(),getY()+1);
        } 
    }
    private void animation(){
        String[] directions ={"left","right","down","up"};
        String curDirection = Greenfoot.getKey();
        String a = "avatar";
        for (int i = 0; i< directions.length;i++){
            if(curDirection == directions[i]){
                System.out.println(a+"_"+directions[i]);
                //setImage(a+"_"+directions[i]);
            } else{System.out.println(curDirection);}
    }
}
}
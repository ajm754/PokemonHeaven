import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PokeWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PokeWorld extends World
{

    /**
     * Constructor for objects of class PokeWorld.
     * 
     */
    public PokeWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 360, 2); 
        spawnStuff();
    }
    private void spawnStuff(){
        int cX = this.getWidth()/2;
        int cY = this.getHeight()/2;
        addObject(new PokePlayer(), cX, cY);
    }
}
